<template>
  <div style="background: #ccc; height: 50px;">
    <span>小明每次花100元</span>
    <button>花钱</button>
    爸爸还剩 ??? 元
  </div>
</template>

<script type="text/ecmascript-6">
  export default {
    name: 'Child2'
  }
</script>
